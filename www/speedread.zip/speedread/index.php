<?php

include '../common.php';
include 'reader.php';